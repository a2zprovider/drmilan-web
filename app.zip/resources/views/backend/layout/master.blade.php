@include('backend.common.header')
@yield('content')
@include('backend.common.footer')